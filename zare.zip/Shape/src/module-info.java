/**
 * 
 */
/**
 * 
 */
module Shape {
}